import os
import json
import logging
from datetime import datetime, timezone
from flask import request, Response
from elasticsearch import Elasticsearch

# === Logging Setup ===
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# === Elasticsearch Configuration ===
ES_HOST = "https://elasticsearch-master.elastic:9200"
ES_USER = "elastic"
ES_PASS = "elastic"
ES_INDEX = "youtube-videos-life"

# === Main Function (for Fission) ===
def main():
    try:
        # Parse query parameters or set default range
        start_date_str = request.args.get("start", "2024-01-01")
        end_date_str = request.args.get("end", datetime.now(timezone.utc).date().isoformat())

        # Convert to ISO datetime string
        start_date = datetime.strptime(start_date_str, "%Y-%m-%d").isoformat() + "Z"
        end_date = datetime.strptime(end_date_str, "%Y-%m-%d").isoformat() + "Z"

        # Connect to Elasticsearch
        es = Elasticsearch(
            hosts=[ES_HOST],
            basic_auth=(ES_USER, ES_PASS),
            verify_certs=False
        )

        # Construct query
        query = {
            "query": {
                "range": {
                    "snippet.publishedAt": {
                        "gte": start_date,
                        "lte": end_date
                    }
                }
            },
            "sort": [{"snippet.publishedAt": "asc"}],
            "size": 10
        }

        # Execute query
        response = es.search(index=ES_INDEX, query=query["query"], sort=query["sort"], size=query["size"])
        hits = response.get("hits", {}).get("hits", [])
        results = [hit["_source"] for hit in hits]

        json_data = {
            "status": 200,
            "result_count": len(results),
            "data": results
        }
        return Response(json.dumps(json_data, ensure_ascii=False), mimetype='application/json')

    except Exception as e:
        logging.error(f"[X] Failed to fetch data: {e}")
        return Response(json.dumps({"status": 500, "message": str(e)}), mimetype='application/json', status=500)
